Python 3.11.1 (tags/v3.11.1:a7a450f, Dec  6 2022, 19:58:39) [MSC v.1934 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.

=========== RESTART: C:/Users/grayc2762/Downloads/P1HW2_GrayCalvin.py ==========
This program calculates and displays travel expenses
Traceback (most recent call last):
  File "C:/Users/grayc2762/Downloads/P1HW2_GrayCalvin.py", line 6, in <module>
    Print()
NameError: name 'Print' is not defined. Did you mean: 'print'?

=========== RESTART: C:/Users/grayc2762/Downloads/P1HW2_GrayCalvin.py ==========
This program calculates and displays travel expenses

Enter the budget: 1200

Enter your travel destination:Nashville

How much do you think you will spend on gas?250
Traceback (most recent call last):
  File "C:/Users/grayc2762/Downloads/P1HW2_GrayCalvin.py", line 12, in <module>
    hotel(input("Approximately,how much will you need for accomodation/hotel?:"))
NameError: name 'hotel' is not defined

=========== RESTART: C:/Users/grayc2762/Downloads/P1HW2_GrayCalvin.py ==========
This program calculates and displays travel expenses

Enter the budget: 1200

Enter your travel destination:Nashville

How much do you think you will spend on gas?250
Approximately,how much will you need for accomodation/hotel?:600

Last,How much do you need for food? 300

------------ Travel Expenses ------------
Location: Nashville
Initial Budget:  1200.0

Fuel: 250.0
Accomodation:  600.0
Food: 300.0

remaining Balance: 50
>>> 
=========== RESTART: C:/Users/grayc2762/Downloads/P1HW2_GrayCalvin.py ==========
This program calculates and displays travel expenses

Enter the budget: 
=========== RESTART: C:/Users/grayc2762/Downloads/P1HW2_GrayCalvin.py ==========
This program calculates and displays travel expenses

Enter the budget: 1200

Enter your travel destination:Nasville

How much do you think you will spend on gas?: 
=========== RESTART: C:/Users/grayc2762/Downloads/P1HW2_GrayCalvin.py ==========
This program calculates and displays travel expenses

Enter the budget: 1200

Enter your travel destination: Nashville

How much do you think you will spend on gas?: 250
Approximately,how much will you need for accomodation/hotel?: 600

Last,How much do you need for food?: 300

------------ Travel Expenses ------------
Location: Nashville
Initial Budget:  1200.0

Fuel: 250.0
Accomodation:  600.0
Food: 300.0

remaining Balance: 50
