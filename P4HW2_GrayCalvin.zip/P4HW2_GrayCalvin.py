# CTI-110
# P4HW2-Salary
# Calvin Gray
# April 28,2023
ovt_total=0
regpay_total=0
grosspay_total=0
employees=0
name = input("Enter Name: ")
while name != "Done":
    
    
    payrate = float(input("Enter pay rate: "))
    hours = float(input("Hours: "))


    if hours > 40:
        regpay = payrate * 40
        ovthrs = hours - 40
        ovtpay = payrate * ovthrs * 1.5
        grosspay = ovtpay + regpay
    else:
        ovtpay=0
        ovthrs=0
        regpay = hours * payrate
        grosspay = ovtpay + regpay
    print('----------------------------------------------')
    print('Employee name:', name)

    print()
    print("Hours Worked" + " "*5 + "Pay Rate"+ " "*5 +"overtime"+" "*5 +"overtime Pay" + " "*5 + "reghour pay" + " "*5 + "gross pay")
    print('----------------------------------------------------------------------------------------------------')

    print(hours,'\t\t',payrate,'\t\t'+ '',ovthrs,'\t\t' + ' $' + str(format(ovtpay,',.2f')) + '\t' + ' $'+str(format(regpay,',.2f')) +'\t'+ ' $' + str(format(grosspay,',.2f')))
    #add up totals
    ovt_total+=ovtpay
    regpay_total+=regpay
    grosspay_total+=grosspay
    employees+= 1
    
    # ask for the next name
    name = input("Enter Name: ")
print("Totals:")
print ("overtime total $",ovt_total)
print ("regpay total $",regpay_total)
print ("grosspay total $",grosspay_total)
print ("employees total",employees)

       
